package com.example.phoneagent

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import java.io.File

object LocalLlm {
    private var engine: Engine? = null
    private var loadedKey: String = ""

    @Synchronized
    fun unload() {
        try { engine?.close() } catch (_: Throwable) {}
        engine = null
        loadedKey = ""
    }

    @Synchronized
    private fun ensure(ctx: Context) {
        val path = Prefs.modelPath
        if (path.isEmpty() || !File(path).exists()) throw IllegalStateException("مدل آفلاین انتخاب نشده")
        val key = path + "|" + Prefs.backend
        if (engine != null && key == loadedKey) return
        unload()
        val backend = if (Prefs.backend == "gpu") Backend.GPU() else Backend.CPU()
        val e = Engine(EngineConfig(modelPath = path, backend = backend, cacheDir = ctx.cacheDir.path))
        e.initialize()
        engine = e
        loadedKey = key
    }

    @Synchronized
    fun generate(ctx: Context, system: String, prompt: String): String {
        ensure(ctx)
        val conv = engine!!.createConversation(ConversationConfig(systemInstruction = Contents.of(system)))
        return conv.use { it.sendMessage(prompt).toString() }
    }
}
