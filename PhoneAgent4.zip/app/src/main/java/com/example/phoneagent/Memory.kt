package com.example.phoneagent

object Memory {
    fun notes(): List<String> = Prefs.notes.split("\n").filter { it.isNotBlank() }

    fun addNote(t: String) {
        val l = notes().toMutableList()
        l.add(t.replace("\n", " ").trim().take(300))
        Prefs.notes = l.takeLast(100).joinToString("\n")
    }

    fun removeNote(i: Int) {
        val l = notes().toMutableList()
        if (i in l.indices) {
            l.removeAt(i)
            Prefs.notes = l.joinToString("\n")
        }
    }

    fun clearNotes() { Prefs.notes = "" }

    fun logs(): List<String> = Prefs.logs.split("\n").filter { it.isNotBlank() }

    fun log(e: String) {
        val l = logs().toMutableList()
        l.add(e.replace("\n", " ").take(200))
        Prefs.logs = l.takeLast(30).joinToString("\n")
    }

    fun clearLogs() { Prefs.logs = "" }
}
