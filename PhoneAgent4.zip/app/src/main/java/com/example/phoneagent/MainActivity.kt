package com.example.phoneagent

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {

    private val BG = 0xFF0F111A.toInt()
    private val CARD = 0xFF1A1D2B.toInt()
    private val CHIP = 0xFF2A2E42.toInt()
    private val ACCENT = 0xFF6C5CE7.toInt()
    private val SUB = 0xFF9AA0B5.toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var scroll: ScrollView
    private lateinit var col: LinearLayout
    private var progressTv: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        scroll = ScrollView(this).apply { setBackgroundColor(BG) }
        setContentView(scroll)
        build()
    }

    override fun onResume() {
        super.onResume()
        val y = scroll.scrollY
        build()
        scroll.post { scroll.scrollTo(0, y) }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        build()
    }

    // ---------------- helpers ----------------
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(c: Int, r: Int): GradientDrawable =
        GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }

    private fun tv(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun add(p: LinearLayout, v: View, top: Int = 8) {
        p.addView(v, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(top) })
    }

    private fun card(title: String, sub: String? = null): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(CARD, 18)
            setPadding(dp(16), dp(14), dp(16), dp(16))
        }
        c.addView(tv(title, 17f, Color.WHITE, true))
        if (sub != null) c.addView(tv(sub, 12f, SUB))
        col.addView(c, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) })
        return c
    }

    private fun btn(label: String, bg: Int = ACCENT, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(11), dp(14), dp(11))
            background = rounded(bg, 14)
            setOnClickListener { onClick() }
        }

    private fun edit(hintText: String, value: String, pwd: Boolean = false): EditText =
        EditText(this).apply {
            hint = hintText
            setText(value)
            setTextColor(Color.WHITE)
            setHintTextColor(SUB)
            textSize = 14f
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(CHIP, 12)
            if (pwd) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun chips(parent: LinearLayout, opts: List<Pair<String, String>>, current: String, onPick: (String) -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val views = mutableListOf<Pair<String, TextView>>()
        fun paint(sel: String) {
            for ((k, v) in views) v.background = rounded(if (k == sel) ACCENT else CHIP, 20)
        }
        for ((k, label) in opts) {
            val v = tv(label, 13f, Color.WHITE).apply {
                setPadding(dp(14), dp(8), dp(14), dp(8))
                setOnClickListener { onPick(k); paint(k) }
            }
            views.add(k to v)
            row.addView(v, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(8) })
        }
        paint(current)
        val hs = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(row)
        }
        add(parent, hs, 10)
    }

    private fun slider(parent: LinearLayout, label: String, min: Int, max: Int, cur: Int, fmt: (Int) -> String, onChange: (Int) -> Unit) {
        val t = tv("$label: ${fmt(cur)}", 13f, SUB)
        add(parent, t, 12)
        val sb = SeekBar(this).apply {
            this.max = max - min
            progress = cur - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + min
                    t.text = "$label: ${fmt(v)}"
                    if (fromUser) onChange(v)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        add(parent, sb, 2)
    }

    private fun switchRow(parent: LinearLayout, label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        val sw = Switch(this).apply {
            text = label
            setTextColor(Color.WHITE)
            isChecked = checked
            setOnCheckedChangeListener { _, v -> onChange(v) }
        }
        add(parent, sw, 10)
    }

    // ---------------- UI ----------------
    private fun build() {
        col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(40))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        scroll.removeAllViews()
        scroll.addView(col)
        col.addView(tv("Phone Agent", 26f, Color.WHITE, true))
        col.addView(tv("دستیار هوش مصنوعی روی صفحه‌ی گوشی", 13f, SUB).apply { setPadding(0, 0, 0, dp(14)) })
        sectionStatus()
        sectionPrivacy()
        sectionBrain()
        sectionBubble()
        sectionVoice()
        sectionMemory()
        sectionSafety()
    }

    private fun sectionStatus() {
        val c = card("وضعیت")
        val acc = AgentService.instance != null
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        add(c, tv((if (acc) "✅ " else "❌ ") + "سرویس دسترسی‌پذیری " + (if (acc) "روشنه" else "خاموشه"), 14f, Color.WHITE), 10)
        if (!acc) {
            add(c, btn("روشن کردن سرویس (Phone Agent رو پیدا کن)") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
            add(c, tv("اگه دکمه خاکستری بود: تنظیمات ← Apps ← Phone Agent ← منوی ⋮ ← Allow restricted settings، بعد دوباره امتحان کن.", 12f, SUB))
        }
        add(c, tv((if (mic) "✅ " else "❌ ") + "اجازه‌ی میکروفون", 14f, Color.WHITE), 10)
        if (!mic) add(c, btn("دادن اجازه‌ی میکروفون") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 5)
        })
    }

    private fun sectionPrivacy() {
        val c = card("🔒 حریم خصوصی", "این نسخه هیچ اجازه‌ی اینترنتی نداره")
        add(c, tv("مدل، حافظه و تنظیمات فقط روی همین گوشی‌ان. خود اپ اجازه‌ی اینترنت نداره، پس نمی‌تونه چیزی بفرسته و پشتیبان‌گیری ابری‌اش هم خاموشه. برای جستجو، دستیار مرورگر خود گوشی رو باز می‌کنه و روی صفحه کلیک می‌کنه و متن صفحه رو فقط با مدل داخل گوشی می‌خونه. فقط خود جستجو (کلمه‌ای که سرچ می‌شه) مثل هر سرچ دستی از مرورگر گوشی می‌ره.", 13f, Color.WHITE), 10)
    }

    private fun sectionBrain() {
        val c = card("مغز دستیار", "مدل آفلاین روی همین گوشی")
        localSection(c)
    }

    private fun localSection(c: LinearLayout) {
        val f = File(Prefs.modelPath)
        val has = Prefs.modelPath.isNotEmpty() && f.exists()
        add(c, tv(if (has) "مدل فعلی: ${f.name} (${f.length() / 1_000_000} MB)" else "هنوز مدلی اضافه نشده", 14f, Color.WHITE), 14)
        add(c, tv("مدل باید فرمت .litertlm باشه. با مرورگر گوشی از huggingface.co/litert-community دانلودش کن (بعضی مدل‌ها لایسنس و ورود می‌خوان) و بعد با دکمه‌ی زیر انتخابش کن. دانلود از خود اپ حذف شده تا اپ اینترنت نخواد.", 12f, SUB))
        add(c, btn("📂 انتخاب فایل مدل از گوشی") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
            startActivityForResult(i, 11)
        }, 10)
        val ptv = tv("", 12f, SUB)
        progressTv = ptv
        add(c, ptv, 6)

        add(c, tv("پردازنده", 13f, Color.WHITE), 14)
        chips(c, listOf("cpu" to "CPU (پایدارتر)", "gpu" to "GPU (سریع‌تر، شاید ناپایدار)"), Prefs.backend) {
            Prefs.backend = it
            LocalLlm.unload()
        }
        slider(c, "حداکثر متن صفحه برای مدل", 2, 24, Prefs.maxScreenChars / 500, { "${it * 500} کاراکتر" }) {
            Prefs.maxScreenChars = it * 500
        }
        add(c, tv("کمتر = سریع‌تر و رم کمتر، ولی مدل کمتر از صفحه می‌بینه.", 12f, SUB), 4)

        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val total = mi.totalMem / 1e9
        val avail = mi.availMem / 1e9
        val modelGb = if (has) f.length() / 1e9 else 0.0
        add(c, tv("رم کل: ${"%.1f".format(total)} GB — آزاد الان: ${"%.1f".format(avail)} GB" +
            (if (has) " — رم لازم برای این مدل حدود ${"%.1f".format(modelGb * 1.3)} GB" else ""), 13f, Color.WHITE), 14)
        add(c, tv("اندروید اجازه نمی‌ده مقدار رم رو دستی تعیین کنی. رمی که مدل می‌گیره از اندازه‌ی خود مدل میاد؛ برای رم کمتر مدل کوچک‌تر انتخاب کن یا «حداکثر متن صفحه» رو کم کن.", 12f, SUB), 4)
        add(c, btn("🧹 آزاد کردن مدل از رم", CHIP) {
            LocalLlm.unload()
            toast("مدل از رم خارج شد")
        }, 8)
    }

    private fun sectionBubble() {
        val c = card("ظاهر حباب", "تغییرات همون لحظه روی حباب اعمال می‌شه. حباب رو با انگشت بکش تا جابه‌جا بشه.")
        val label = edit("متن یا ایموجی حباب", Prefs.bubbleLabel)
        label.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c1: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c1: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val t = s?.toString()?.take(3) ?: ""
                if (t.isNotEmpty()) Prefs.bubbleLabel = t
            }
        })
        add(c, label, 12)

        val colors = listOf(0xFF6C5CE7, 0xFF00B894, 0xFFE17055, 0xFF0984E3, 0xFFD63031, 0xFFFDCB6E, 0xFFE84393, 0xFF2D3436)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (cl in colors) {
            val v = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(cl.toInt())
                    setStroke(dp(2), Color.WHITE)
                }
                setOnClickListener { Prefs.bubbleColor = cl.toInt() }
            }
            row.addView(v, LinearLayout.LayoutParams(dp(34), dp(34)).apply { marginEnd = dp(10) })
        }
        add(c, HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }, 12)

        slider(c, "اندازه", 36, 96, Prefs.bubbleSize, { "$it" }) { Prefs.bubbleSize = it }
        slider(c, "شفافیت", 30, 100, Prefs.bubbleAlpha, { "$it٪" }) { Prefs.bubbleAlpha = it }
        chips(c, listOf("right" to "راست", "left" to "چپ"), Prefs.bubbleSide) {
            Prefs.bx = -1
            Prefs.bubbleSide = it
        }
    }

    private fun sectionVoice() {
        val c = card("زبان و صدا", "زبانی که میکروفون گوش می‌ده و پاسخ‌ها با اون خونده می‌شن. توی خود حباب هم دکمه‌ی زبان هست.")
        chips(c, Prefs.LANGS.map { it.first to it.third }, Prefs.lang) { Prefs.lang = it }
        switchRow(c, "میکروفون (تشخیص گفتار)", Prefs.voiceEnabled) { Prefs.voiceEnabled = it }
        add(c, tv("هشدار: تشخیص گفتار توسط اپ گوگل گوشی انجام می‌شه، نه این اپ. من فقط «ترجیحاً آفلاین» رو درخواست می‌کنم ولی نمی‌تونم تضمین کنم که اون اپ چیزی نفرسته. برای کاملاً آفلاین بودن، توی تنظیمات گوشی بسته‌ی زبان آفلاین (Speech services by Google) رو دانلود کن، یا میکروفون رو خاموش بذار و فقط تایپ کن. به همین خاطر به‌صورت پیش‌فرض خاموشه.", 12f, SUB), 8)
        switchRow(c, "خواندن پاسخ‌ها با صدا", Prefs.speak) { Prefs.speak = it }
        add(c, tv("خوندن صدا هم با موتور TTS گوشی انجام می‌شه. بیشتر صداها آفلاین کار می‌کنن.", 12f, SUB), 8)
    }

    private fun sectionMemory() {
        val c = card("حافظه", "چیزهایی که دستیار درباره‌ی تو یادش مونده. هر وقت بخوای پاکش کن.")
        val notes = Memory.notes()
        if (notes.isEmpty()) add(c, tv("هنوز چیزی ذخیره نشده", 13f, SUB), 10)
        notes.forEachIndexed { i, n ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            r.addView(tv(n, 13f, Color.WHITE), LinearLayout.LayoutParams(0, WRAP, 1f))
            r.addView(btn("حذف", CHIP) { Memory.removeNote(i); build() }, LinearLayout.LayoutParams(WRAP, WRAP))
            add(c, r, 8)
        }
        val note = edit("یه چیز برای یادآوری اضافه کن", "")
        add(c, note, 12)
        add(c, btn("➕ افزودن") {
            val t = note.text.toString().trim()
            if (t.isNotEmpty()) { Memory.addNote(t); build() }
        }, 8)
        if (notes.isNotEmpty()) add(c, btn("پاک کردن همه‌ی یادداشت‌ها", 0xFFB00020.toInt()) { Memory.clearNotes(); build() }, 8)

        add(c, tv("کارهای اخیر", 14f, Color.WHITE, true), 16)
        val logs = Memory.logs().takeLast(10).reversed()
        if (logs.isEmpty()) add(c, tv("—", 13f, SUB), 6)
        for (l in logs) add(c, tv("• $l", 12f, SUB), 4)
        if (logs.isNotEmpty()) add(c, btn("پاک کردن تاریخچه", CHIP) { Memory.clearLogs(); build() }, 10)
    }

    private fun sectionSafety() {
        val c = card("امنیت و حریم خصوصی")
        add(c, tv("اپ‌های ممنوعه: توی این اپ‌ها دستیار صفحه رو اصلاً نمی‌خونه و چیزی نمی‌فرسته (نام بسته یا بخشی از اون، با ویرگول جدا کن؛ مثلاً: bank, telegram, whatsapp)", 12f, SUB), 8)
        val b = edit("bank, telegram, whatsapp", Prefs.blocked)
        add(c, b, 8)
        add(c, btn("ذخیره") { Prefs.blocked = b.text.toString().trim(); toast("ذخیره شد") }, 8)
        add(c, tv("فیلدهای رمز همیشه از متن صفحه حذف می‌شن. دستیار قبل از پرداخت، حذف اطلاعات و فرستادن پیام برای بقیه از تو می‌پرسه.", 12f, SUB), 10)
        add(c, btn("🗑 پاک کردن همه‌ی داده‌ها (حافظه، تاریخچه، مدل)", 0xFFB00020.toInt()) {
            Memory.clearNotes()
            Memory.clearLogs()
            LocalLlm.unload()
            File(filesDir, "model.litertlm").delete()
            Prefs.modelPath = ""
            toast("همه‌چیز پاک شد")
            build()
        }, 12)
    }

    // ---------------- model import / download ----------------
    private fun progress(s: String) {
        runOnUiThread { progressTv?.text = s }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 11 && resultCode == RESULT_OK) {
            data?.data?.let { importModel(it) }
        }
    }

    private fun importModel(uri: Uri) {
        var total = 0L
        var name = "model"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = c.getString(ni) ?: name
                if (si >= 0) total = c.getLong(si)
            }
        }
        if (!name.endsWith(".litertlm")) toast("هشدار: پسوند فایل .litertlm نیست؛ ممکنه کار نکنه")
        Thread {
            try {
                val dest = File(filesDir, "model.litertlm")
                contentResolver.openInputStream(uri)!!.use { inp ->
                    FileOutputStream(dest).use { out ->
                        val buf = ByteArray(1 shl 20)
                        var done = 0L
                        var last = 0L
                        while (true) {
                            val n = inp.read(buf)
                            if (n <= 0) break
                            out.write(buf, 0, n)
                            done += n
                            if (done - last > 32_000_000) {
                                last = done
                                progress("در حال کپی مدل… ${done / 1_000_000} از ${total / 1_000_000} MB")
                            }
                        }
                    }
                }
                LocalLlm.unload()
                Prefs.modelPath = dest.absolutePath
                progress("✅ مدل آماده شد")
                runOnUiThread { build() }
            } catch (e: Exception) {
                progress("خطا: ${e.message}")
            }
        }.start()
    }
}
