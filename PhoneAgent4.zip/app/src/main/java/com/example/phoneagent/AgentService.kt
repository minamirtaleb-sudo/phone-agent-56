package com.example.phoneagent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class MaxHeightScroll(c: Context, private val maxH: Int) : ScrollView(c) {
    override fun onMeasure(w: Int, h: Int) {
        super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST))
    }
}

class AgentService : AccessibilityService() {

    companion object {
        @Volatile var instance: AgentService? = null
    }

    @Volatile var stopFlag = false
    @Volatile var running = false

    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var root: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var statusCard: LinearLayout? = null
    private var statusText: TextView? = null
    private var inputPanel: LinearLayout? = null
    private var langChip: TextView? = null
    private var lastStatus = ""
    private var expanded = false
    private var nodes: List<AccessibilityNodeInfo> = emptyList()
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null

    private val bubbleKeys = setOf("bubbleColor", "bubbleSize", "bubbleAlpha", "bubbleLabel", "bubbleSide")
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key != null && key in bubbleKeys) main.post { rebuild() }
    }

    override fun onServiceConnected() {
        instance = this
        Prefs.init(this)
        Prefs.sp.registerOnSharedPreferenceChangeListener(prefListener)
        main.post { rebuild() }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        try { Prefs.sp.unregisterOnSharedPreferenceChangeListener(prefListener) } catch (_: Exception) {}
        try { root?.let { wm?.removeView(it) } } catch (_: Exception) {}
        tts?.shutdown()
        recognizer?.destroy()
        super.onDestroy()
    }

    // ---------------- Overlay ----------------
    private fun px(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = px(r).toFloat() }

    private fun pill(label: String, bg: Int): TextView = TextView(this).apply {
        this.text = label
        setTextColor(Color.WHITE)
        textSize = 13f
        gravity = Gravity.CENTER
        setPadding(px(12), px(8), px(12), px(8))
        background = rounded(bg, 16)
    }

    private fun langShort(): String = Prefs.LANGS.firstOrNull { it.first == Prefs.lang }?.second ?: "FA"

    private fun rebuild() {
        val manager = wm ?: (getSystemService(WINDOW_SERVICE) as WindowManager).also { wm = it }
        root?.let { try { manager.removeView(it) } catch (_: Exception) {} }

        val left = Prefs.bubbleSide == "left"
        val screenW = resources.displayMetrics.widthPixels
        val panelW = minOf(px(320), (screenW * 0.92).toInt())
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val match = ViewGroup.LayoutParams.MATCH_PARENT

        val r = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = if (left) Gravity.START else Gravity.END
        }

        // status card
        val sText = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 13f
            text = lastStatus
            setPadding(px(12), px(10), px(12), px(10))
        }
        val sScroll = MaxHeightScroll(this, px(220)).apply { addView(sText) }
        val closeX = pill("✕", 0xFF2A2E42.toInt()).apply { setOnClickListener { setStatus("") } }
        val sCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(0xEE181A24.toInt(), 16)
            setPadding(px(4), px(4), px(8), px(4))
            visibility = if (lastStatus.isBlank()) View.GONE else View.VISIBLE
        }
        sCard.addView(sScroll, LinearLayout.LayoutParams(0, wrap, 1f))
        sCard.addView(closeX, LinearLayout.LayoutParams(wrap, wrap))
        r.addView(sCard, LinearLayout.LayoutParams(panelW, wrap).apply { bottomMargin = px(6) })
        statusCard = sCard
        statusText = sText

        // input panel
        val input = EditText(this).apply {
            hint = "چی کار کنم؟ (بنویس یا 🎤)"
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF8A90A5.toInt())
            textSize = 14f
            maxLines = 4
            setPadding(px(10), px(8), px(10), px(8))
            background = rounded(0xFF2A2E42.toInt(), 12)
        }
        val mic = pill("🎤", 0xFF2A2E42.toInt())
        val go = pill("اجرا ▶", Prefs.bubbleColor)
        val stop = pill("■ توقف", 0xFFB00020.toInt())
        val lang = pill(langShort(), 0xFF2A2E42.toInt())
        langChip = lang
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        for (v in listOf(mic, go, stop, lang)) {
            row.addView(v, LinearLayout.LayoutParams(wrap, wrap).apply { marginEnd = px(6) })
        }
        val ip = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(0xF2181A24.toInt(), 16)
            setPadding(px(10), px(10), px(10), px(10))
            visibility = if (expanded) View.VISIBLE else View.GONE
        }
        ip.addView(input, LinearLayout.LayoutParams(match, wrap).apply { bottomMargin = px(8) })
        ip.addView(row)
        r.addView(ip, LinearLayout.LayoutParams(panelW, wrap).apply { bottomMargin = px(6) })
        inputPanel = ip

        go.setOnClickListener {
            val t = input.text.toString()
            input.setText("")
            submit(t)
        }
        mic.setOnClickListener {
            listen { t -> input.setText(""); submit(t) }
        }
        stop.setOnClickListener {
            stopFlag = true
            recognizer?.cancel()
            setStatus("متوقف شد")
        }
        lang.setOnClickListener {
            val i = Prefs.LANGS.indexOfFirst { it.first == Prefs.lang }
            Prefs.lang = Prefs.LANGS[(i + 1) % Prefs.LANGS.size].first
            lang.text = langShort()
        }

        // bubble
        val size = px(Prefs.bubbleSize)
        val bubble = TextView(this).apply {
            text = Prefs.bubbleLabel
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            textSize = Prefs.bubbleSize / 3.2f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Prefs.bubbleColor)
            }
            alpha = Prefs.bubbleAlpha / 100f
        }
        r.addView(bubble, LinearLayout.LayoutParams(size, size))

        val p = WindowManager.LayoutParams(
            wrap, wrap,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                (if (expanded) 0 else WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or (if (left) Gravity.START else Gravity.END)
            x = if (Prefs.bx < 0) 0 else Prefs.bx
            y = if (Prefs.by < 0) px(300) else Prefs.by
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }

        bubble.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f
            var sy = 0f
            var ox = 0
            var oy = 0
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - sx).toInt()
                        val dy = (e.rawY - sy).toInt()
                        if (abs(dx) > 12 || abs(dy) > 12) moved = true
                        if (moved) {
                            p.x = if (left) ox + dx else ox - dx
                            p.y = oy + dy
                            try { manager.updateViewLayout(r, p) } catch (_: Exception) {}
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) setExpanded(!expanded)
                        else { Prefs.bx = p.x; Prefs.by = p.y }
                    }
                }
                return true
            }
        })

        root = r
        params = p
        manager.addView(r, p)
    }

    private fun setExpanded(v: Boolean) {
        expanded = v
        val p = params ?: return
        val r = root ?: return
        inputPanel?.visibility = if (v) View.VISIBLE else View.GONE
        p.flags = if (v) p.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        else p.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        if (v) langChip?.text = langShort()
        try { wm?.updateViewLayout(r, p) } catch (_: Exception) {}
    }

    fun setStatus(s: String) {
        lastStatus = s
        main.post {
            statusText?.text = s
            statusCard?.visibility = if (s.isBlank()) View.GONE else View.VISIBLE
        }
    }

    private fun submit(task: String) {
        val t = task.trim()
        if (t.isEmpty()) return
        if (running) { setStatus("یک کار در حال اجراست؛ اول «توقف» رو بزن"); return }
        val err = Agent.precheck()
        if (err != null) { setStatus(err); return }
        setExpanded(false)
        stopFlag = false
        running = true
        Thread {
            try { Agent.run(t, this) } finally { running = false }
        }.start()
    }

    // ---------------- Voice ----------------
    private fun listen(onText: (String) -> Unit) {
        if (!Prefs.voiceEnabled) {
            setStatus("میکروفون از پنل اپ (بخش زبان و صدا) خاموشه")
            return
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            setStatus("اول داخل اپ اجازه‌ی میکروفون رو بده")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            setStatus("تشخیص گفتار روی این گوشی در دسترس نیست")
            return
        }
        setStatus("🎤 گوش می‌دم…")
        recognizer?.destroy()
        val rec = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = rec
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                setStatus("میکروفون: خطای $error (اینترنت یا بسته‌ی زبان گوگل رو چک کن)")
            }
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) {
                    setStatus("چیزی نشنیدم")
                } else {
                    setStatus("«$t»")
                    onText(t)
                }
            }
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(eventType: Int, p: Bundle?) {}
        })
        rec.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.lang)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        })
    }

    fun speak(text: String) {
        if (!Prefs.speak) return
        main.post {
            val loc = Locale.forLanguageTag(Prefs.lang)
            val existing = tts
            if (existing == null) {
                tts = TextToSpeech(this) { st ->
                    if (st == TextToSpeech.SUCCESS) {
                        tts?.language = loc
                        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "agent")
                    }
                }
            } else {
                existing.language = loc
                existing.speak(text, TextToSpeech.QUEUE_FLUSH, null, "agent")
            }
        }
    }

    // ---------------- Reading the screen ----------------
    fun installedApps(limit: Int): String {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(i, 0)
            .map { it.loadLabel(packageManager).toString() }
            .distinct().sorted().joinToString(", ").take(limit)
    }

    private fun isBlocked(pkg: String): Boolean =
        Prefs.blocked.split(",", "\n").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
            .any { pkg.lowercase().contains(it) }

    fun dumpScreen(limit: Int): String {
        var r = rootInActiveWindow
        var tries = 0
        while ((r == null || r.packageName == packageName) && tries < 6) {
            Thread.sleep(300)
            r = rootInActiveWindow
            tries++
        }
        if (r == null) return "(screen not readable)"
        val pkg = r.packageName?.toString() ?: ""
        if (isBlocked(pkg)) return "BLOCKED_APP:$pkg"
        val list = mutableListOf<AccessibilityNodeInfo>()
        val sb = StringBuilder("app: $pkg\n")
        val d = resources.displayMetrics
        sb.append("screen: ${d.widthPixels}x${d.heightPixels}\n")
        fun walk(n: AccessibilityNodeInfo) {
            if (!n.isVisibleToUser) return
            val raw = if (n.isPassword) "(password field hidden)"
            else (n.text ?: n.contentDescription ?: n.hintText)?.toString()?.take(80)
            val interesting = n.isClickable || n.isEditable || n.isScrollable || n.isCheckable || !raw.isNullOrBlank()
            if (interesting) {
                val rect = Rect()
                n.getBoundsInScreen(rect)
                val flags = buildString {
                    if (n.isClickable) append("C")
                    if (n.isEditable) append("E")
                    if (n.isScrollable) append("S")
                    if (n.isChecked) append("+")
                }
                sb.append("[${list.size}] ${n.className?.toString()?.substringAfterLast('.')} \"${raw ?: ""}\" $flags (${rect.centerX()},${rect.centerY()})\n")
                list.add(n)
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
        }
        walk(r)
        nodes = list
        return sb.toString().take(limit)
    }

    // ---------------- Doing things ----------------
    fun execute(a: JSONObject): String = try {
        val ok = when (a.optString("action")) {
            "tap" -> tapNode(a.getInt("id"))
            "long_tap" -> {
                val n = nodes.getOrNull(a.getInt("id"))
                if (n == null) false else {
                    val r = Rect()
                    n.getBoundsInScreen(r)
                    gesture(r.centerX().toFloat(), r.centerY().toFloat(), r.centerX().toFloat(), r.centerY().toFloat(), 900)
                }
            }
            "tap_xy" -> {
                val x = a.getDouble("x").toFloat()
                val y = a.getDouble("y").toFloat()
                gesture(x, y, x, y, 60)
            }
            "type" -> typeText(a)
            "enter" -> pressEnter()
            "scroll" -> scroll(a.optString("direction", "down"))
            "drag" -> gesture(
                a.getDouble("x1").toFloat(), a.getDouble("y1").toFloat(),
                a.getDouble("x2").toFloat(), a.getDouble("y2").toFloat(), 700
            )
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "open_app" -> openApp(a.optString("name"), a.optString("package"))
            "web_search" -> openUrl("https://www.google.com/search?q=" + URLEncoder.encode(a.getString("query"), "UTF-8"))
            "open_url" -> openUrl(a.getString("url"))
            "wait" -> { Thread.sleep(1500); true }
            else -> false
        }
        if (ok) "ok" else "failed"
    } catch (e: Exception) {
        "error: ${e.message}"
    }

    private fun tapNode(id: Int): Boolean {
        val n = nodes.getOrNull(id) ?: return false
        var c: AccessibilityNodeInfo? = n
        while (c != null) {
            if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            c = c.parent
        }
        val r = Rect()
        n.getBoundsInScreen(r)
        return gesture(r.centerX().toFloat(), r.centerY().toFloat(), r.centerX().toFloat(), r.centerY().toFloat(), 60)
    }

    private fun typeText(a: JSONObject): Boolean {
        val text = a.getString("text")
        val byId: AccessibilityNodeInfo? = if (a.has("id")) nodes.getOrNull(a.getInt("id")) else null
        val target = byId ?: rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val append = a.optBoolean("append")
        val old = if (append && !target.isShowingHintText) (target.text?.toString() ?: "") else ""
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, old + text)
        }
        if (target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return true
        // Fallback: clipboard + paste (works in editors that refuse SET_TEXT)
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("agent", text))
        if (!append) {
            val sel = Bundle().apply {
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, target.text?.length ?: 0)
            }
            target.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
        }
        return target.performAction(AccessibilityNodeInfo.ACTION_PASTE)
    }

    private fun pressEnter(): Boolean {
        if (Build.VERSION.SDK_INT < 30) return false
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        return f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    private fun scroll(dir: String): Boolean {
        val d = resources.displayMetrics
        val w = d.widthPixels.toFloat()
        val h = d.heightPixels.toFloat()
        return when (dir) {
            "down" -> gesture(w / 2, h * 0.75f, w / 2, h * 0.25f, 400)
            "up" -> gesture(w / 2, h * 0.25f, w / 2, h * 0.75f, 400)
            "left" -> gesture(w * 0.25f, h / 2, w * 0.75f, h / 2, 400)
            "right" -> gesture(w * 0.75f, h / 2, w * 0.25f, h / 2, 400)
            else -> false
        }
    }

    private fun openApp(name: String, pkg: String): Boolean {
        val pm = packageManager
        var target = pkg
        if (target.isBlank()) {
            val q = name.lowercase()
            val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val match = list.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
                ?: list.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            target = match?.activityInfo?.packageName ?: return false
        }
        val launch = pm.getLaunchIntentForPackage(target) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        return true
    }

    private fun openUrl(url: String): Boolean {
        if (!url.startsWith("https://") && !url.startsWith("http://")) return false
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        return true
    }

    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long): Boolean {
        val p = Path().apply {
            moveTo(x1, y1)
            if (x1 != x2 || y1 != y2) lineTo(x2, y2)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build()
        val latch = CountDownLatch(1)
        var ok = false
        main.post {
            dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { ok = true; latch.countDown() }
                override fun onCancelled(d: GestureDescription?) { latch.countDown() }
            }, null)
        }
        latch.await(5, TimeUnit.SECONDS)
        return ok
    }
}
