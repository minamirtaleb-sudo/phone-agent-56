package com.example.phoneagent

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    lateinit var sp: SharedPreferences

    val LANGS = listOf(
        Triple("fa-IR", "FA", "فارسی"),
        Triple("en-US", "EN", "English"),
        Triple("ar-SA", "AR", "العربية"),
        Triple("tr-TR", "TR", "Türkçe"),
        Triple("de-DE", "DE", "Deutsch"),
        Triple("fr-FR", "FR", "Français"),
        Triple("es-ES", "ES", "Español"),
        Triple("ru-RU", "RU", "Русский")
    )

    fun init(c: Context) {
        if (!::sp.isInitialized) {
            sp = c.applicationContext.getSharedPreferences("cfg2", Context.MODE_PRIVATE)
        }
    }

    private fun s(k: String, d: String): String = sp.getString(k, d) ?: d
    private fun i(k: String, d: Int): Int = sp.getInt(k, d)
    private fun b(k: String, d: Boolean): Boolean = sp.getBoolean(k, d)
    private fun ps(k: String, v: String) { sp.edit().putString(k, v).apply() }
    private fun pi(k: String, v: Int) { sp.edit().putInt(k, v).apply() }
    private fun pb(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply() }

    var modelPath: String
        get() = s("modelPath", "")
        set(v) = ps("modelPath", v)
    var backend: String
        get() = s("backend", "cpu")
        set(v) = ps("backend", v)
    var maxScreenChars: Int
        get() = i("maxScreenChars", 6000)
        set(v) = pi("maxScreenChars", v)

    var bubbleColor: Int
        get() = i("bubbleColor", 0xFF6C5CE7.toInt())
        set(v) = pi("bubbleColor", v)
    var bubbleSize: Int
        get() = i("bubbleSize", 56)
        set(v) = pi("bubbleSize", v)
    var bubbleAlpha: Int
        get() = i("bubbleAlpha", 90)
        set(v) = pi("bubbleAlpha", v)
    var bubbleLabel: String
        get() = s("bubbleLabel", "AI")
        set(v) = ps("bubbleLabel", v)
    var bubbleSide: String
        get() = s("bubbleSide", "right")
        set(v) = ps("bubbleSide", v)
    var bx: Int
        get() = i("bx", -1)
        set(v) = pi("bx", v)
    var by: Int
        get() = i("by", -1)
        set(v) = pi("by", v)

    var lang: String
        get() = s("lang", "fa-IR")
        set(v) = ps("lang", v)
    var speak: Boolean
        get() = b("speak", false)
        set(v) = pb("speak", v)
    var voiceEnabled: Boolean
        get() = b("voiceEnabled", false)
        set(v) = pb("voiceEnabled", v)
    var blocked: String
        get() = s("blocked", "")
        set(v) = ps("blocked", v)
    var notes: String
        get() = s("notes", "")
        set(v) = ps("notes", v)
    var logs: String
        get() = s("logs", "")
        set(v) = ps("logs", v)
}
